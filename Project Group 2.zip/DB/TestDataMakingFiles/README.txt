COMPILES WITH
g++ -std=c++11 TestFileCreator.cpp