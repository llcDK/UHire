# UHire

This is for the UOW assignment for CSIT314. It is a car rental system similar to UBER, accept for renting cars. It is a web based project.
